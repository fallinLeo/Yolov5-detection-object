#include <iostream>

/**
 * @function main
 * @brief Main function
 */
int main( void )
{
    //! [hello_world]
    std::cout << "Hello World!";
    //! [hello_world]

    return 0;
}
